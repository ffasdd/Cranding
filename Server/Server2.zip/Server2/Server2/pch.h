#pragma once
#include <iostream>
#include<array>
#include<vector>
#include<map>
#include<set>
#include<unordered_map>
#include<unordered_set>
#include<mutex>
#include<thread>
#include<atomic>
using namespace std;

#include <winsock2.h>
#include<MSWSock.h>
#include<ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib,"mswsock.lib")


