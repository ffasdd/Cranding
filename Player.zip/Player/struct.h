struct PlayerInfo
{

};
struct MonsterInfo
{

};
