#pragma once
#include <stack>

extern thread_local uint32				LThreadId;
