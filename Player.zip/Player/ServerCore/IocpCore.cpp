#include "pch.h"
#include "IocpCore.h"
#include "Over_Exp.h"

IocpCore GIocpCore;

IocpCore::IocpCore() // cp ���� 
{
	_iocpHandle = ::CreateIoCompletionPort(INVALID_HANDLE_VALUE, 0, 0, 0);
}

IocpCore::~IocpCore()
{
	::CloseHandle(_iocpHandle);
}

bool IocpCore::Register(SOCKET* _socket) // ���� CP�� ��� 
{
	// iocp�� ��� 
	return ::CreateIoCompletionPort(_socket, _iocpHandle, 9999, 0);

}

void IocpCore::Dispatch()
{
	while (true)
	{
		DWORD num_bytes;
		ULONG_PTR key;
		WSAOVERLAPPED* over;
		BOOL ret = GetQueuedCompletionStatus(_iocpHandle, &num_bytes, &key, &over, INFINITE);
		Over_Exp* ex_over = reinterpret_cast<Over_Exp*>(over);
		if (FALSE == ret)
		{
			if (ex_over->GetType() == COMP_TYPE::Accept) cout << "Accept Error";
			else {
				cout << "GQCS Error on client[" << key << "]\n";
				//disconnect(static_cast<int>(key));
				//if (ex_over->_comp_type == OP_SEND) delete ex_over;
				//continue;
				
			}
		}
		if ((0 == num_bytes) && ((ex_over->GetType() == COMP_TYPE::Recv) || (ex_over->GetType() == COMP_TYPE::Send)))
		{
			cout << "Disconnect" << endl;
			return;
		}
		switch (ex_over->GetType())
		{
		case COMP_TYPE::Accept: {
			cout << " Accept " << endl;
			break;
		} 
		case COMP_TYPE::Recv: {
			break;
		}
		case COMP_TYPE::Send: {
			break;
		}

		
		}
		
	}
}


