#pragma once
class IocpCore
{
public:
	IocpCore();
	~IocpCore();

public:
	bool Register(SOCKET* _socket);
	HANDLE GetHandle() { return _iocpHandle; }
	void Dispatch(); // WorkerThread 

private:
	HANDLE _iocpHandle;
};

extern IocpCore GIocpCore;
