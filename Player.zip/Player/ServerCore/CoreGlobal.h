#pragma once

extern class ThreadManager* GThreadManager;